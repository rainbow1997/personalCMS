<?php
namespace Controller;
require_once(ROOT.'\classes\Model\Cart.php');
class Cart
{
    private $cartModel;
    public function __construct()
    {
        
        $this->cartModel=new \Cart();
        if(@$_SESSION['Cart']==null)
            $_SESSION['Cart']=[];//intori kardam ta hamoon avval araye farz beshe ta array_push error nade
    }
    public function addItem()
    {
        
        if(isset($_POST)&&!empty($_POST))
        {
   
            $choosenItem=unserialize(urldecode(($_POST['encodeProduct'])));//badanramzeshkon
            @$_SESSION['totalcost']+=$choosenItem['cost'];
            array_push($_SESSION['Cart'],$choosenItem);
           
           
           require_once(ROOT.'\classes\view\Cart.php');
            
            //echo 'In this time your totalCost is :'.$_SESSION['totalcost'];
            
        }
        else if(@$_SESSION['Cart']==null){
           
            $message='you havent order';
            
            require_once(ROOT.'\classes\view\message.php');
            //session_unset();
        }
      
                    
        
    }
   
}

