<?php
namespace Controller;

require_once(ROOT.'\classes\Model\DataBase.php');
require_once(ROOT.'\classes\Model\Comment.php');
require_once(ROOT.'\classes\Model\SendComment.php');

class SendComment
{
    private $databaseObj;
    private $sendCommentModel;
    
    public function __construct()
    {
        $this->databaseObj=new \DataBase();
        
    }
    public function sendComment($articleid)
    {
        //$articleid=$_REQUEST['id'];//HAMOON AVVAL KAR VAGHTI SAFE COMMENT BAZ SHOD ARTICLEID GEREFTE MISHE AZ GET
       
        if(isset($_POST)&&!empty($_POST)){//INJA VAGHTI KARBAR DOKMERO CLICK KARD SHOROO BE KAR MIKONE
           $dateOfSend=date("Y/m/d");//badan ke kamel kardi inam bardar
           
           $this->sendCommentModel=new \SendComment($_POST['fname'], $_POST['lname'], $_POST['email'], $_POST['text'], $dateOfSend,$articleid);
            $this->sendCommentModel->sendComment();
            $message="your comment is sent";
            require_once(ROOT.'\classes\view\message.php');
            //       echo'your register is done';//badan ye safe braye chap message bezar
        }
        else 
        {
            require_once(ROOT.'\classes\view\SendComment.php');
        }
    }
}

