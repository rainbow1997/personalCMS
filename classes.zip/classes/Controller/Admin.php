<?php
namespace Controller;
require_once(ROOT.'\classes\Model\Login.php');
require_once(ROOT.'\classes\Model\ShowArticle.php');
class Admin
{
    private $information=[];
    private $adminLogin;
    private $showArticleModel;
    public function __construct()
    {
        $this->adminLogin=new Login('Admin','__admin','adlogin');
        $this->showArticleModel=new \ShowArticle();
    }
    public function login()
    {
        $this->adminLogin->checklogin(false,true);//nmikham peygham not logino  chap kone bara hamin false dadam
        
    }
    public function adminPanel()
    {
        
       $this->adminLogin->checklogin();//in harbar sessiono check mikone ta bebine karbar login karde ya na        
       
    }
    public function manageContent()
    {
        $articles=$this->showArticleModel->showAllArticle();
        var_dump($articles);
        require_once(ROOT.'\classes\view\managecontent.php');
    }
    
}

