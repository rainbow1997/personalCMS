<?php
namespace Controller;//inkaro kardm ta error moshabeh boodn esm classa ba line 6 nade
echo dirname(__FILE__);

require_once(ROOT.'\classes\Model\DataBase.php');
require_once(ROOT.'\classes\Model\Article.php');
require_once(ROOT.'\classes\Model\ShowArticle.php');
//use Model\ShowArticle;
//if(file_exists("C:/xampp/htdocs/MWS/Santa/classes/Model/DataBase.php")) { echo'salam';}
class ShowArticle
{
 // private $databaseObjs = new \DataBase();//error new mide chera 
  private $databaseObj;
  private $showCommentObj;
  // private $showArticleModel=new ShowArticle();
  private $showArticleModel;
  public function __construct()
  {
      $this->databaseObjs=new \DataBase();
      $this->showArticleModel=new \ShowArticle();
      $this->showCommentObj=new ShowComment();
      
  }
  public function seeAllArticle()
  {
   //   $databaseObj = new \DataBase();
      $article=array();
      $comments=array();//tarif araye ta to scope for az das nare
      $countOfAllArticle=$this->showArticleModel->countOfArticle();   
      echo 'irani'.$countOfAllArticle;
    //  echo var_dump($this->showArticleModel->showArticle(0));
      
      for($i=0;$i<$countOfAllArticle;$i++)
      {
          $article[$i]=$this->showArticleModel->showArticle($i);//i=id yek araye bere to meghdar hararaye article
          $comments[$i]=$this->showCommentObj->showCommentByArticleId($i);
      }
     
      //comment part//
      require_once(ROOT.'\classes\view\ShowArticle.php');
      
          
  }
  public function seeOneArticle($id)
  {
      return $article_array=$this->databaseObj->getFetchData($id);//hamin ke 2ta arayero beham nesbat bedi copy anjam mishe?
      
  }
  
}
?>