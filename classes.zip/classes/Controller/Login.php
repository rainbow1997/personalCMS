<?php
namespace Controller;
require_once(ROOT.'\classes\Model\Login.php');
class Login
{

    private $loginModel;
    private $sessionName;
    private $tableName;
    private $loginaddress;
    public function __construct($sessionName,$tableName,$loginaddress)
    {
        $this->loginModel=new \Model\Login();
        $this->sessionName=$sessionName;
        $this->tableName=$tableName;
        $this->loginaddress=$loginaddress;

    }
    public function login()
    {
        $loginaddress=$this->loginaddress;//baraye chap too khorooji
        //class login kolli nam session o nam jadval marbute ro midi etebar sanji mikone
        if(!empty($_SESSION[$this->sessionName]))
        {
            echo 'You are Logged in Mr/Mrs'.$_SESSION[$this->sessionName];
        }
        else{
            if(isset($_POST)&&!empty($_POST))
            {
                $_POST['password']=hash_hmac("sha256",$_REQUEST['password'],_Hash_Code);//kare dorostie???
                var_dump($_POST);
                $resultOfLogin=$this->loginModel->login($_POST, $this->tableName);//count recordaro mide yani age doros bood etelat 1 vagarna 0 mide
                
                
                if($resultOfLogin>0)
                {
                        $_SESSION[$this->sessionName]=$_REQUEST['username'];
                        $message= 'you are loggedin';
                        require_once(ROOT.'\classes\view\message.php');
                }
                else
                    {
                        $message='eshtebah';
                        require_once(ROOT.'\classes\view\message.php');
                    }
                    
         
            }
            else 
            {
                
                require_once(ROOT.'\classes\view\Login.php');
            }
        }
        
        
    }
    public function checklogin($canprintmessage=true,$canprintmessage2=true)
    {
        if(@$_SESSION[$this->sessionName]==null){
            $this->login();
        if($canprintmessage==true)
        {
            echo'You are not login';
        }
        }
        else 
        {
            if($canprintmessage2==true)
            {
                echo'You Are Logged in Mr/Mrs'.$_SESSION[$this->sessionName];
            }
        }
    }
}

