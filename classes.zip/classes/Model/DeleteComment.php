<?php
//badan baraye mosabat manfi boodan natije query ha fekri kon

class DeleteComment extends Comment
{
    public function __construct($fname,$lname,$email,$text,$dateOfSend,$canSee,$id)
    {
        parent::__construct($fname, $lname, $email, $text, $dateOfSend, $canSee);
        $this->id=$id;
    }
    public function deleteOneComment($id)
    {
     parent::getDataBaseObj()->query("DROP FROM comments WHERE ID='".$id."'"); 
    }
    public function deleteAllComment()
    {
        parent::getDataBaseObj()->query("DROP FROM comments"); 
    }
}