<?php

require_once("DataBase.php");
class Comment
{
    private $fname;
    private $lname;
    private $email;
    private $text;
    private $dateOfSend;
    private $canSee;
    private $databaseObj;//database khali bashe error mide inkaro mikonim ta az ghati shodan ba namespace asli jologiribeshe
    public function __construct($fname,$lname,$email,$text,$dateOfSend)
    {
        $this->databaseObj=new \DataBase();
        $this->fname=$fname;
        $this->lname=$lname;
        $this->email=$email;
        $this->text=$text;
        $this->dateOfSend=$dateOfSend;
       
    }
    public function getFname()
    {
        return $this->fname;
        
    }
    public function getLname()
    {
        return $this->lname;
        
    }
    public function getEmail()
    {
        return $this->email;
        
    }
    public function getText()
    {
        return $this->text;
    }
    public function getDateOfSend()
    {
        return $this->dateOfSend;
    }
    public function getCanSee()
    {
        return $this->canSee;
    }
    public function getDataBaseObj()
    {
        return $this->databaseObj;
    }
}