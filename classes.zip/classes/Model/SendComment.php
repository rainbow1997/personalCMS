<?php
class SendComment extends Comment
{
    private $articleId;
    public function __construct($fname,$lname,$email,$text,$dateOfSend,$articleId)
    {
        parent::__construct($fname, $lname, $email, $text, $dateOfSend);
      $this->articleId=$articleId;
    }
    public function sendComment()
    {
        parent::getDataBaseObj()->query("INSERT INTO comments values('".parent::getFname()."','".parent::getLname()."','".parent::getEmail()."','".parent::getText()."','".parent::getDateOfSend()."',false,'".$this->articleId."',NULL)");
    }
}
