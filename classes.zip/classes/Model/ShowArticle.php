<?php
require_once('DataBase.php');
class ShowArticle
{
  //  private $id;
  //  public function __construct($title,$subject,$barchasb,$text,$timeOfPublish,$cansee,$id)
   // {
   //     parent::__construct($title,$subject,$barchasb,$text,$timeOfPublish,$cansee);
    //    $this->id=$id;
   // }
   private $databaseObj;
    public function __construct()
    {
        $this->databaseObj=new \DataBase();
    }
    public function showAllArticle()
    {
        $resultQuery=$this->databaseObj->query("select * from article");
        return $this->databaseObj->getFetchAll($resultQuery);
    }
    public function showArticle($id)
    {
        $resultQuery=$this->databaseObj->query("SELECT * FROM article WHERE ID='".$id."'");
        return $this->databaseObj->getFetchData($resultQuery);
       //ye araye anjomani bargasht mide 
    }
    public  function countOfArticle()
    {
        $resultQuery=$this->databaseObj->query("select count(*) from article");
        $count=$this->databaseObj->getFetchArray($resultQuery);
         return $count[0];
    }
}
?>