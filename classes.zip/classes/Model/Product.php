<?php
require_once("DataBase.php");
class Product
{
    
    private $databaseObj;
    public function __construct()
    {
        $this->databaseObj=new \DataBase();
    }
    
    public function showAllProduct()
    {
  
        $resultQuery=$this->databaseObj->query("select * from product");
        return $product=$this->databaseObj->getFetchAll($resultQuery);//khodesh ye araye 2bodi barmigardoone
        //$product[productnumber][field]
    }
    
    public function showProductById($id)
    {
        $resultQuery=$this->databaseObj->query("SELECT * FROM product WHERE ID='".$id."'");
        return $this->databaseObj->getFetchData($resultQuery);//ye araye yekbodi anjoamni array['name']=name
    }
}
/*
class Product
{
    private $name;
    private $groupid;
    private $productSerial;
    private $cost;
    private $id;
    private $databaseObj=new \DataBase();
    public function __construct($name,$groupid,$productSerial,$cost)
    {
        $this->name=$name;
        $this->groupid=$groupid;
        $this->productSerial=$productSerial;
        $this->cost=$cost;
        
    }
    public function setProduct()
    {
        $this->databaseObj->query("INSERT INTO product values('".$this->name."','".$this->groupid."','".$this->productSerial."','".$this->cost."')");
        $this->id=mysqli_insert_id($this->databaseObj->getConnection());
    }
    
    public function getName()
    {
        return $this->name;
        
    }
    public function getGroupId()
    {
        return $this->groupid;
    }
    public function getProductSerial()
    {
        return $this->productSerial;
        
    }
    public function getCost()
    {
        return $this->cost;
    }
    
}
*/