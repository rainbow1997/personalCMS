<?php

class DeleteArticle extends Article
{
    private $id;
    public function __construct($id)
    {
        $this->id=$id;
    }
    public function deleteAllArticle()
    {
        parent::getDataBaseObj()->query("DROP FROM article");
    }
    public function deleteArticle($id)
    {
        
       parent::getDataBaseObj()->query("DROP FROM article WHERE ID='".$id."'");
    }
}
?>