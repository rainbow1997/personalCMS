<?php
require_once("DataBase.php");
class Customers
{
    private $databaseObj;
    public function __construct()
    {
        $this->databaseObj=new DataBase();
    }
  /*  public function Customers($registerArray)
    {
        $query=$this->databaseObj->query("insert into customers values('".$registerArray['fname']."','".$registerArray['lname']."','".$registerArray['username']."','".$registerArray['password']."','".$registerArray['phone']."','".$registerArray['email']."')");
    }
    */
    public function loginCustomer($loginArray)
    {
       $this->databaseObj->escaping($loginArray);//migire kolle arayero escape mikone
        return $query=$this->databaseObj->query("select * from customers where username='".$loginArray['username']."'and password='".$loginArray['password']."'");
       
    }
    public function RegisterCustomer($registerArray)
    {
        $this->databaseObj->escaping($registerArray);
        $query=$this->databaseObj->query("insert into customers values('".$registerArray['fname']."','".$registerArray['lname']."','".$registerArray['username']."','".$registerArray['password']."','".$registerArray['phone']."','".$registerArray['email']."',NULL)");
        if($query)
            return true;
        else 
            return false;
    }
    
}

