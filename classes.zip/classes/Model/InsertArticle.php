﻿<?php

require_once("Article.php");
class InsertArticle extends Article
{ 
    //public static $id=0;khode mysql ido betartib ziad mikone
	public function __construct($title,$subject,$label,$text,$timeOfPublish,$cansee)
	{
		parent::__construct($title,$subject,$label,$text,$timeOfPublish,$cansee);
		
	}
	public function insertArticle()
	{
		echo'<br><br>'.$this->getTitle();
		echo'salamirani';
		parent::getDataBaseObj()->query("INSERT INTO article Values('".$this->getTitle()."','".$this->getSubject()."','".$this->getLabel()."','".$this->getText()."','".$this->getTimeOfPublish()."','".$this->getCanSee()."',NULL)");
			
		
	}	
}
?>