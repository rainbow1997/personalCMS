<?php
namespace Model;
require_once("DataBase.php");
class Login
{
    private $databaseObj;
    public function __construct()
    {
        $this->databaseObj=new \DataBase();
    }
    public function login($loginArray,$tablename)
    {
        $this->databaseObj->escaping($loginArray);//migire kolle arayero escape mikone
        $query=$this->databaseObj->query("select * from $tablename where username='".$loginArray['username']."'and password='".$loginArray['password']."'");
        return mysqli_num_rows($query);
    }
}

