﻿<?php
class DataBase
{
	private $host='localhost';
	private $username='root';
	private $password='';
	private $dbname='test';
	private $connection;
	
	function __construct()
	{
		echo'salam';
		$this->connectDataBase();//برای دسترسی به متدهای درون کلاس باید اینگونه عمل شود
		echo's';
		
	}
	 function connectDataBase()
	{
		$this->connection=mysqli_connect($this->host,$this->username,$this->password,$this->dbname);
		if(mysqli_connect_error())
		{
			exit('خطا دراتصال به  پایگاه داده');
		}	
	}
	 function query($query)
	{
	     echo $query;
		$setQuery=mysqli_query($this->connection,$query);
		if(!$setQuery)
		{
			echo'پرس و جوی مورد نظر انجام نشد';
			echo $query;
		}
		return $setQuery;
		
		
	}
	 function closeDataBase()
	{
		mysqli_close();
	}
	 function getFetchData($resultQuery)
	{
		return mysqli_fetch_assoc($resultQuery);
		
	}
	public function getConnection()
	{
	    return $this->connection;
	}
	public function getFetchArray($resultQuery)
	{
	    return mysqli_fetch_array($resultQuery,MYSQLI_NUM);
	}
	public function getFetchAll($resultQuery)
	{
	    return mysqli_fetch_all($resultQuery);
	}
	public function escaping($array)
	{
	   // var_dump($array);
	//    exit();
	    foreach($array as $key=>$value)
	    {
	        $array[$key]=mysqli_real_escape_string($this->getConnection(),$value);
	    }
	   /* for($i=0;$i<count($array);$i++)
	    {
	        $array[$i]=mysqli_real_escape_string($this->getConnection(),$array[$i]);
	    }
	    */
	}
	
}
?>