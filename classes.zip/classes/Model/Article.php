﻿
<?php
require_once("DataBase.php");
class Article
{
		//har zirclass id khodesho dashte bashe
	//beyn article va insert article az tarigh polymoryphism ertebat barghararkon
	private $title;
	private $subject;
	private $label;
	private $text;
	private $timeOfPublish;
	private $cansee;
	private $id;
	
	private  $databaseObj;//aya az lahaz amniati kar e dorostie?
	//private $id;
	function __construct($title,$subject,$label,$text,$timeOfPublish,$cansee)
	{
		$this->title=$title;
		$this->subject=$subject;
		$this->label=$label;
		$this->text=$text;
		$this->timeOfPublish=$timeOfPublish;
		$this->cansee=$cansee;
		//$this->id++;//be ezaye harmatlab yeki afzayesh bede harmatlab=yekshey
		$this->databaseObj=new DataBase();
		
	}	
	public function showArticle()
	{
		//matlabo be soorat araye barmigardoone
		$article=array($this->title,
		$this->subject,
		$this->label,
		$this->text,
		$this->timeOfPublish,
		$this->cansee,
		$this->id);
	}
	public function showCountOfArticles()
	{
	    $this->databaseObj->getFetchData("SELECT COUNT(*) FROM article");
	}
	function getTitle()
	{
		return $this->title; 
	}
	public function getSubject()
	{
		
		return $this->subject;
	}
	public function getLabel()
	{
		return $this->label;
	}
	public function getText()
	{
		return $this->text;
	}
	public function getTimeOfPublish()
	{
		return $this->timeOfPublish;
		
	}
	public function getCanSee()
	{
		return $this->cansee;
	}
	public function getDataBaseObj()
	{
	    return $this->databaseObj;
	}
}
?>