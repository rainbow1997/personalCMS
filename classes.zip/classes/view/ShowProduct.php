<?php
foreach($product as $value)
{
    echo $value.'<br>';
}

?>
<form action="index.php?address=cart" method="post">
enter amount for buy<input type="text" name=amount ><br>
<input type="hidden" name="encodeProduct" value="<?php echo $encodeProduct;?>">
<input type="submit" name=submit value=submit>
</form>