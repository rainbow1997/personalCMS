<html>
<head>
</head>
<body>
<?php echo $message; ?>
</body>
</html>