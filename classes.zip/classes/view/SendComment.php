
<html>
<head>

</head>
<body>
<form  method="post">
<input type="text" name="fname">fname
<input type="text" name="lname">lname
<input type="text" name="email">email
<input type="text" name="text">text
<input type="hidden" name="articleid" value="<?php echo $articleid;?>">
<br>

<input type="submit" name="submit" value="send">Send
</form>
</body>
</html>