<br>
<?php

foreach($product as $val){
    foreach($val as $val2)
        echo $val2;
    
   ?>
  	<a href="index.php?address=showproductbyid&id=<?php echo $val[4];?>"> for order click this</a>
   <br>
<?php 
}