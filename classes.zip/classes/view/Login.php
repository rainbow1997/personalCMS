<?php


?>
   
    <form action="index.php?address=<?php echo $loginaddress; //harcontrolleri ke requiresh karde bayad ino set kone?>" method=post>
   username <input type=text name=username><br>
   password <input type=text name=password><br>
    <input type=submit name=submit value=submit>
    </form>
    