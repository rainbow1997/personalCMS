<?php
      
        foreach($_SESSION['Cart'] as $product)
        {
            foreach($product as $value)
                echo $value;
            
                   //ye araye darim be esm session ke chanta meghdar dare ke harmeghdaresh ye arayas
               //pas vaghti baravval mishkanim be araye miresim
        }
        ?>
        totalcost:<?php echo $_SESSION['totalcost'] ;?>
        
       <a href=index.php?address=setorder>For Set Order Click Here</a>
      
    
   

?>
