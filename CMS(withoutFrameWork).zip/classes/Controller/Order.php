<?php
namespace Controller;

require_once(ROOT.'\classes\Model\Order.php');

class Order
{
    private $databaseObj;
    private $serializeData;
    private $customerusername;
    private $totalcost;
  
    public function __construct(){
          $this->databaseObj=new \Order();
          //$this->serializeData=serialize($_SESSION['Cart']);//tamam sefareshat yek sefaresh kamel yek karbar
         // $this->customerusername=$_SESSION['registeredUser'];
         // $this->totalcost=$_SESSION['totalcost'];
    }
    public function addFullOrder()
    {
      
        if(@$_SESSION['registeredUser']==null)
        {
            $message='First You haveto login';
            require_once(ROOT.'\classes\view\message.php');
        }
        else{
  
        $this->databaseObj->setOrder(serialize($_SESSION['Cart']),$_SESSION['registeredUser'],$_SESSION['totalcost']);
        $message='Your order has been set';
        require_once(ROOT.'\classes\view\message.php');
        }
        }
    
}

