<?php
namespace Controller;

require_once(ROOT.'\classes\Model\DataBase.php');

require_once(ROOT.'\Route.php');
require_once(ROOT.'\classes\Model\Article.php');
require_once(ROOT.'\classes\Model\InsertArticle.php');
class InsertArticle
{
    private $databaseObj;
    private $insertArticleModel;
    
    public function __construct()
    {
        $this->databaseObj=new \DataBase();
       
    }
    public function insertArticle()
    {
       @ $submitButton=$_POST['submit'];
        if(isset($submitButton)){
        $title=$_POST['title'];
        $subject=$_POST['subject'];
        $label=$_POST['label'];
        $text=$_POST['text'];
        $timeOfPublish=$_POST['timeOfPublish'];
        $cansee=$_POST['cansee'];
        $this->insertArticleModel=new \InsertArticle($title, $subject, $label, $text, $timeOfPublish, $cansee);
        $this->insertArticleModel->insertArticle();
    }
    }
    
}
    
