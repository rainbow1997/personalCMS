<?php
namespace Controller;
require_once(ROOT.'\classes\Model\Customers.php');
require_once(ROOT.'\classes\Controller\Login.php');
class Customers
{
    private $CustomersModel;
    private $customerLoginObj;
    public function __construct()
    {
        $this->CustomersModel=new \Customers();
        $this->customerLoginObj=new login("registeredUser","customers","login");
        
    }
   
    public function loginCustomer()
    {
        $this->customerLoginObj->Login('login');
    }
}

