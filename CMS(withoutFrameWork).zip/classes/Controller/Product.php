<?php
namespace Controller;

require_once(ROOT.'\classes\Model\Product.php');
class Product
{
   private $ProductModel;
   public function __construct()
   {
       $this->ProductModel=new \Product();
   }
   public function showAllProduct()
   {
       $product=$this->ProductModel->showAllProduct();
       require_once(ROOT.'\classes\view\ShowAllProduct.php');
    /*  $countOfProduct=$this->ProductModel->countAllOfProduct();
      $product=[];
      for($i=0;$i<$countOfProduct;$i++)
      {
          $product[$i]=$this->showProductById($i);
      }
      $product;//product[id][field]
       
   */
   }
   public function showProductById($id)
   {
       
       $canorder=true;
       if(!isset($_SESSION['registeredUser']))
             $canorder=false;       
       $product=$this->ProductModel->showProductById($id);
       $serializeProduct=serialize($product);
        $encodeProduct=urlencode($serializeProduct);
       
       require_once(ROOT.'\classes\view\ShowProduct.php');
       
   }
}