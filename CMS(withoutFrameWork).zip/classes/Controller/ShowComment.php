<?php
namespace Controller;

//require_once('C:\wamp64\www\MWS\Santa\classes\Model\DataBase.php');
require_once(ROOT.'\classes\Model\ShowComment.php');
class ShowComment
{
    private $databaseObj;
    private $showCommentModel;
    public function __construct()
    {
    
        $this->showCommentModel=new \ShowComment();
    }
    public function showAllComment()
    {
       $comments=$this->showCommentModel->showAllComment();
   
    }
    public function showCommentByArticleId($articleId)
    {
      
        return ( $comment=$this->showCommentModel->ShowCommentByArticleId($articleId));
        
        /*foreach($comment as $value)
        {
            echo $value;
        }
        */
    }
    public function countAllComments()
    {
        return $this->showCommentModel->countAllComments();
    }
    
}

