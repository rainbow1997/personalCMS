<?php

?>
<form action="index.php?address=register"method=post>
fname<input type=text name=fname ><br>
lname<input type=text name=lname ><br>
username<input type=text name=username ><br>
password<input type=text name=password ><br>
phone<input type=text name=phone><br>
email<input type=text name=email ><br>
<input type=submit value=submit name=submit>
</form>
'; 
}
?>