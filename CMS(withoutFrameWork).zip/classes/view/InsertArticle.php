<?php
use Controller\InsertArticle;
require_once(ROOT.'\classes\Controller\InsertArticle.php');
$insertArticleController=new \Controller\InsertArticle();
$insertArticleController->insertArticle();
?>
<html>
<head>

</head>
<body>
<form  method="post">
<input type="text" name="title">title
<input type="text" name="subject">subject
<input type="text" name="label">label
<input type="text" name="text">text
<input type="text" name="timeOfPublish">timeofpublish
<input type="radio" name="cansee" value="1">cansee
<br>
<input type="radio" name="cansee" value="0">cannotsee
<input type="submit" name="submit" value="send">Send
</form>
<?php 

?>
</body>
</html>