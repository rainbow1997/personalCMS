
require_once('../config.php');
require_once(ROOT.'\classes\Controller\Order.php');
    echo'Set OrderPage';
    $OrderControllerObj=new \Controller\Order();
    $OrderControllerObj->addFullOrder();//ettelato to controller ba session gereftim
  //  session_unset();
