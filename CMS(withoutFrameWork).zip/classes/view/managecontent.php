<?php
var_dump($articles);
foreach($articles as $article){
    foreach($article as $art)
        echo '<br>'.$art;
    ?>
    <a href="index.php?address=showcommentbyid&id=<?php echo $article[6];?>">see This Content Comments</a>
    <a href="index.php?address=deletecommentbyid&id=<?php echo $article[6];?>">delete this content</a><!--  kari kin ke nazaratam hazf she -->
    <a href="index.php?address=editcontentbyid&id=<?php echo $article[6];?>">edit this content</a>
	
   <?php 
    echo'<hr>';
}

   