<?php

//use Controller\SendComment;
?>


?>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<?php 
/*
$obj=new ShowArticle();
echo'hiiii';
$allArticle=$obj->showAllArticle();//ye araye 2bodi be ma mide ke araye[shomarematlab][namsotoon];
$showCommentController=new \Controller\ShowComment();

foreach($allArticle as $article)
{
    foreach($article as $value)
    echo $value;
    echo'<br> <a href=SendComment.php?articleid='.$article['id'].'>SendComment</a>';
    $comment=$showCommentController->showCommentByArticleId($article['id']);
    echo 'nazarat:<br>';
    foreach($comment as $value)
    {
        echo $value;
    }
    echo'<hr>';
}
echo 'insert Article <a href=InsertArticle.php>insertlink</a>';

?>
<hr>
<?php 
echo '<br> Products:<br>';
$productObj=new \Controller\Product();
$products=$productObj->showAllProduct();
var_dump($products);
//exit();
foreach($products as $product)
{
    echo $product['id'].'-';
    foreach($product as $value)
       echo  $value.'    ';
        echo'<a href=ShowProduct.php?id='.$product['id'].'>see more about this product</a><br>';
        
}
?>
<!--    for(int i=0;i< -->
</body>
</html>
*/