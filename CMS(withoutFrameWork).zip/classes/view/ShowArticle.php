<html>
<head>

</head>
<body>

<?php foreach($article as $value){
           foreach($value as $val)
               echo $val;
?>
<a href="index.php?address=sendComment&id=<?php echo $value['id'] ?>"> send comment</a>          
           
           Comments:<br>
<?php 
foreach($comments[$value['id']] as $value){
    //ma to araye comments be ezaye shomarandehash commentaro bara har matlab negah midarim
    //pas bayad shekoondan kolle commentaro ($comments) be ezaye commentaye oon matlab shoroo konim
       if($value!=null){//yani age oon matlab comment nadasht dg bazesh nakon
      foreach($value as $val)
             echo "$val=>";
      echo'<br>';
       }
}
?>
<hr>
<?php 
}
?>

<?php ?>
</body>
</html>