<?php
//be ezaye har kalaye sabad kharid ye sefaresh
require_once("DataBase.php");
class Order
{
    //private $customerid;
   // private $productsid;
   // private $amountOfProduct;
    private $databaseObj;//bekhatere ineke DataBase.php namespace Model nadare
    //private $id;
    //private $id; moghe ferestadan null mifrestim chon auto incremente 
    public function __construct()
    {
        $this->databaseObj=new \DataBase();
       /* $this->customerid=$customerid;
        $this->productid=$productid;
        $this->amountOfProduct=$amountOfProduct;
    */
    }
    public function setOrder($serializedata,$customerusername,$totalcost)
    {
        $query=$this->databaseObj->query("INSERT INTO ORDERS VALUES('".$customerusername."','".$serializedata."','".$totalcost."',NULL)");
        //$id=mysqli_insert_id($this->databaseObj->getConnection());
    }
    public function DeleteOneOrder()
    {
        //$this->databaseObj->query("DROP FROM orders WHERE ID='".$this->id."'");
    }
    public function setId($id)
    {
        $this->id=$id;
    }
    /*public function DeleteAllOrder()
    {
        $this->databaseObj->query("DROP FROM orders");
    }
    */
}