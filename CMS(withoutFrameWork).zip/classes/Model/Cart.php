<?php
require_once("DataBase.php");
class Cart
{
    private $databaseObj;
    public function __construct()
    {
        $this->databaseObj=new DataBase();
    }
   
}