﻿<?php
require_once("DataBase.php");
require_once("InsertArticle.php");
$obj=new DataBase();
$objin=new  InsertArticle("s","sd","sdf","text",time(),true);
$objin->insertArticle();
echo dirname(__FILE__);
?>