<?php
namespace Model;
require_once("DataBase.php");
class Admin
{
    private $databaseObj;
    
    public function __construct()
    {
        $this->databaseObj=new \DataBase();
    }
 
}

