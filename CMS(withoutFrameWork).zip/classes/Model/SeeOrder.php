<?php

class SeeOrder
{
   private $amountOfAllOrders;
   private $databaseObj=new \DataBase();
    public function seeAllOrder()
    {
        $this->databaseObj->getFetchData("SELECT * FROM orders");
        $this->amountOfAllOrders=mysqli_insert_id($this->databaseObj->getConnection());
    }
    public function seeOneOrderWithId($id)
    {
        $this->databaseObj->getFetchData("SELECT * FROM orders id='".$id."'");
    }
    public function seeOrderWithCustomerId($customerid)
    {
        $this->databaseObj->getFetchData("SELECT * FROM orders id='".$customerid."'");
    }
}