<?php
require_once('DataBase.php');
class ShowComment
{
    private $databaseObj;
    public function __construct()
    {
        $this->databaseObj=new DataBase();
        
    }
    public function countAllComments()
    {
        $resultQuery=$this->databaseObj->query("select count(*) from comments");
        $count=$this->databaseObj->getFetchArray($resultQuery);
        return $count[0];//tedad commenta barmigarde chon tedad az sotoon count(*) bargardoonde mishe
    }
    public function ShowCommentByArticleId($articleId)
    {
        $articleid=0;
        $resultQuery=$this->databaseObj->query("select * from comments where articleid='".$articleId."'");
        return $this->databaseObj->getFetchAll($resultQuery);
       
    }
    public function ShowAllComment()
    {
        $resultQuery=$this->databaseObj->query("select * from comments");
        return $this->databaseObj->getFetchArray($resultQuery);
        //array[0ya1]['name']=name az avvali
    }
}

/*
 
class ShowComment extends Comment
{
    //in id nmigire balke be methodash midim
  public function __construct()
  {
      //parent::__construct($fname, $lname, $email, $text, $dateOfSend, $canSee);
      
  }
  public function showOneComment($id)
  {
      parent::getDataBaseObj()->getFetchData("SELECT * FROM comments WHERE ID='".$id."'");
  }
  public function showAllComment()
  {
      //aya in araye anjomani araye i mishe ke har ozvessh arayas?
      return parent::getDataBaseObj()->getFetchData("SELECT * FROM comments");//badan limit bezar barash
  }
  public function showNotSeeComment()
  {
      parent::getDataBaseObj()->getFetchData("SELECT * FROM comments WHERE CANSEE=false");//badan limit bezar barash
  }
}
*/
