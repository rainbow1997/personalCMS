<?php
session_start();
define('ROOT','C:\wamp64\www\MWS\Santa');
define('_Hash_Code','@___@#!@!#323141321');
